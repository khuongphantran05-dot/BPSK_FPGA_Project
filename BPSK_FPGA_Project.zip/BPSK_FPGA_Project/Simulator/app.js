document.addEventListener('DOMContentLoaded', () => {
    // Configuration
    const F_CARRIER = 5; 
    const POINTS_PER_BIT = 100; 
    let VISIBLE_BITS = 4; 

    // UI Elements
    const modeSelect = document.getElementById('modeSelect');
    const snrInput = document.getElementById('snrInput');
    const snrValue = document.getElementById('snrValue');
    const phaseInput = document.getElementById('phaseInput');
    const phaseValue = document.getElementById('phaseValue');
    const speedInput = document.getElementById('speedInput');
    const speedValue = document.getElementById('speedValue');
    const bitsInput = document.getElementById('bitsInput');
    
    const randomizeBtn = document.getElementById('randomizeBtn');
    const simulateBtn = document.getElementById('simulateBtn');
    const pauseBtn = document.getElementById('pauseBtn');
    const audioBtn = document.getElementById('audioBtn');
    
    // Stats Elements
    const simBerEl = document.getElementById('simBer');
    const theoryBerEl = document.getElementById('theoryBer');

    // Chart instances
    let charts = {};
    let animationId = null;
    let currentOffset = 0;
    let isPaused = false;
    let scrollSpeed = 2;

    // Audio Context
    let audioCtx = null;
    let osc = null;
    let noiseGain = null;
    let masterGain = null;
    let audioEnabled = false;

    // Simulation Data Buffer
    let simBuffer = {
        time: [],
        msg: [],
        bpsk: [],
        noisy: [],
        demod: [],
        constellation: [] 
    };

    function initCharts() {
        const commonOptions = {
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            elements: { point: { radius: 0 }, line: { borderWidth: 2 } },
            scales: {
                x: { display: false }, 
                y: { grid: { color: 'rgba(255,255,255,0.1)' }, ticks: { color: '#94a3b8' } }
            },
            plugins: { legend: { labels: { color: '#f8fafc' } } },
            interaction: { mode: 'index', intersect: false }
        };

        const createChart = (id, label, color, yMin, yMax) => {
            const ctx = document.getElementById(id).getContext('2d');
            return new Chart(ctx, {
                type: 'line',
                data: { labels: [], datasets: [{ label, data: [], borderColor: color, tension: 0.1 }] },
                options: { ...commonOptions, scales: { ...commonOptions.scales, y: { ...commonOptions.scales.y, min: yMin, max: yMax } } }
            });
        };

        charts.msg = createChart('msgChart', '1. Digital Data', '#00ffcc', -0.5, 1.5);
        charts.bpsk = createChart('bpskChart', '2. Modulated Signal', '#ff007f', -1.5, 1.5);
        charts.noisy = createChart('noisyChart', '3. Received (AWGN)', '#ffaa00', -3.5, 3.5);
        charts.demod = createChart('demodChart', '4. Demodulator (Integrator)', '#b026ff', null, null);

        // Constellation Chart
        const constCtx = document.getElementById('constellationChart').getContext('2d');
        charts.constellation = new Chart(constCtx, {
            type: 'scatter',
            data: {
                datasets: [{
                    label: 'Received Symbols',
                    data: [],
                    backgroundColor: '#00ffcc',
                    pointRadius: 4, pointBackgroundColor: 'rgba(0, 255, 204, 0.7)', borderColor: '#00ffcc', borderWidth: 1,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: false,
                scales: {
                    x: { 
                        min: -2, max: 2, 
                        grid: { color: 'rgba(255,255,255,0.1)' }, 
                        title: { display: true, text: 'In-Phase (I)', color: '#94a3b8' }
                    },
                    y: { 
                        min: -2, max: 2, 
                        grid: { color: 'rgba(255,255,255,0.1)' },
                        title: { display: true, text: 'Quadrature (Q)', color: '#94a3b8' }
                    }
                },
                plugins: { legend: { display: false } }
            }
        });
    }

    function initAudio() {
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            
            osc = audioCtx.createOscillator();
            osc.type = 'sine';
            
            const bufferSize = audioCtx.sampleRate * 2;
            const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
            const output = noiseBuffer.getChannelData(0);
            for (let i = 0; i < bufferSize; i++) {
                output[i] = Math.random() * 2 - 1;
            }
            const noiseSource = audioCtx.createBufferSource();
            noiseSource.buffer = noiseBuffer;
            noiseSource.loop = true;
            
            noiseGain = audioCtx.createGain();
            masterGain = audioCtx.createGain();
            masterGain.gain.value = 0.05; // Base volume
            
            osc.connect(masterGain);
            noiseSource.connect(noiseGain);
            noiseGain.connect(masterGain);
            masterGain.connect(audioCtx.destination);
            
            osc.start();
            noiseSource.start();
        }
        if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
    }

    function drawEyeDiagram() {
        const canvas = document.getElementById('eyeDiagramChart');
        const ctx = canvas.getContext('2d');
        const width = canvas.parentElement.clientWidth;
        const height = canvas.parentElement.clientHeight;
        canvas.width = width;
        canvas.height = height;

        ctx.clearRect(0, 0, width, height);

        // Draw grid
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, height / 2);
        ctx.lineTo(width, height / 2);
        ctx.moveTo(width / 2, 0);
        ctx.lineTo(width / 2, height);
        ctx.stroke();

        if (simBuffer.noisy.length === 0) return;

        const mode = modeSelect.value;
        const samplesPerSymbol = mode === 'QPSK' ? POINTS_PER_BIT * 2 : POINTS_PER_BIT;
        const traces = Math.floor(simBuffer.noisy.length / samplesPerSymbol);
        
        ctx.strokeStyle = 'rgba(255, 0, 127, 0.15)'; // Neon pink with low opacity for overlay
        ctx.lineWidth = 1.5;

        const yScale = height / 6; // map -3 to 3 approx
        const yOffset = height / 2;

        for (let i = 0; i < traces - 1; i++) {
            ctx.beginPath();
            for (let j = 0; j < samplesPerSymbol * 2; j++) { // Draw 2 symbols wide
                const index = i * samplesPerSymbol + j;
                if (index >= simBuffer.noisy.length) break;
                
                const val = simBuffer.noisy[index];
                const x = (j / (samplesPerSymbol * 2)) * width;
                const y = yOffset - (val * yScale);
                
                if (j === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
            }
            ctx.stroke();
        }
    }

    function erfc(x) {
        const z = Math.abs(x);
        const t = 1 / (1 + 0.5 * z);
        const r = t * Math.exp(-z * z - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806 + t * (0.27886807 + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277)))))))));
        return x >= 0 ? r : 2 - r;
    }

    function gaussianRandom() {
        let u = 0, v = 0;
        while(u === 0) u = Math.random();
        while(v === 0) v = Math.random();
        return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
    }

    function generateDataBuffer() {
        const bitString = bitsInput.value;
        const baseBits = bitString.split('').map(b => parseInt(b));
        if (baseBits.some(b => isNaN(b) || (b !== 0 && b !== 1))) {
            return false;
        }

        const mode = modeSelect.value;
        let paddedBits = [...baseBits];
        if (mode === 'QPSK' && paddedBits.length % 2 !== 0) {
            paddedBits.push(0); // padding for even bits
        }

        const REPEATS = 50;
        let bits = [];
        for (let i = 0; i < REPEATS; i++) {
            bits = bits.concat(paddedBits);
        }

        const snrDb = parseFloat(snrInput.value);
        const snrLinear = Math.pow(10, snrDb / 10);
        const Eb = 1;
        const N0 = Eb / snrLinear;
        const noiseStdDev = Math.sqrt(N0 / 2);
        
        const phaseOffsetDeg = parseFloat(phaseInput.value);
        const phaseOffsetRad = phaseOffsetDeg * (Math.PI / 180);

        simBuffer.time = [];
        simBuffer.msg = [];
        simBuffer.bpsk = [];
        simBuffer.noisy = [];
        simBuffer.demod = [];
        simBuffer.constellation = [];
        
        let errorCount = 0;
        let symbolsCount = 0;

        if (mode === 'BPSK') {
            const theoryBer = 0.5 * erfc(Math.sqrt(snrLinear));
            theoryBerEl.textContent = theoryBer.toExponential(4);

            for (let i = 0; i < bits.length; i++) {
                const bit = bits[i];
                const symbol = bit === 1 ? 1 : -1;
                
                let integrator_i = 0;
                let integrator_q = 0;

                for (let j = 0; j < POINTS_PER_BIT; j++) {
                    const t = (i * POINTS_PER_BIT + j) / POINTS_PER_BIT;
                    simBuffer.time.push(t);
                    simBuffer.msg.push(bit);

                    const tx_carrier = Math.cos(2 * Math.PI * F_CARRIER * t);
                    const modulated = symbol * tx_carrier;
                    simBuffer.bpsk.push(modulated);

                    const noise = gaussianRandom() * noiseStdDev;
                    const noisy = modulated + noise;
                    simBuffer.noisy.push(noisy);

                    const rx_carrier_i = Math.cos(2 * Math.PI * F_CARRIER * t + phaseOffsetRad);
                    const rx_carrier_q = -Math.sin(2 * Math.PI * F_CARRIER * t + phaseOffsetRad);
                    
                    integrator_i += noisy * rx_carrier_i;
                    integrator_q += noisy * rx_carrier_q;
                    simBuffer.demod.push(integrator_i);
                }

                const norm_i = integrator_i / (POINTS_PER_BIT / 2);
                const norm_q = integrator_q / (POINTS_PER_BIT / 2);
                simBuffer.constellation.push({ x: norm_i, y: norm_q });

                const decidedBit = integrator_i > 0 ? 1 : 0;
                if (decidedBit !== bit) errorCount++;
                symbolsCount++;
            }
            simBerEl.textContent = (errorCount / symbolsCount).toFixed(4);
            VISIBLE_BITS = 4;

        } else if (mode === 'QPSK') {
            const theoryBer = 0.5 * erfc(Math.sqrt(0.5 * snrLinear)); // approx
            theoryBerEl.textContent = theoryBer.toExponential(4);

            for (let i = 0; i < bits.length; i += 2) {
                const b1 = bits[i];
                const b2 = bits[i+1];
                
                // QPSK mapping: 00 -> 45deg, 01 -> 135deg, 11 -> -135deg, 10 -> -45deg
                let tx_i = b1 === 1 ? -1 : 1;
                let tx_q = b2 === 1 ? -1 : 1;
                
                let tx_phase = Math.atan2(tx_q, tx_i);
                
                let integrator_i = 0;
                let integrator_q = 0;

                for (let j = 0; j < POINTS_PER_BIT * 2; j++) { // Double duration for 2 bits
                    const t = ((i/2) * (POINTS_PER_BIT*2) + j) / POINTS_PER_BIT;
                    simBuffer.time.push(t);
                    simBuffer.msg.push(b1 === 1 ? 1 : 0); // simplify msg display

                    const tx_carrier = Math.cos(2 * Math.PI * F_CARRIER * t + tx_phase);
                    const modulated = tx_carrier;
                    simBuffer.bpsk.push(modulated);

                    const noise = gaussianRandom() * noiseStdDev;
                    const noisy = modulated + noise;
                    simBuffer.noisy.push(noisy);

                    const rx_carrier_i = Math.cos(2 * Math.PI * F_CARRIER * t + phaseOffsetRad);
                    const rx_carrier_q = -Math.sin(2 * Math.PI * F_CARRIER * t + phaseOffsetRad);
                    
                    integrator_i += noisy * rx_carrier_i;
                    integrator_q += noisy * rx_carrier_q;
                    simBuffer.demod.push(integrator_i);
                }

                const norm_i = integrator_i / POINTS_PER_BIT;
                const norm_q = integrator_q / POINTS_PER_BIT;
                simBuffer.constellation.push({ x: norm_i, y: norm_q });

                const dec_b1 = norm_i < 0 ? 1 : 0;
                const dec_b2 = norm_q < 0 ? 1 : 0;
                
                if (dec_b1 !== b1) errorCount++;
                if (dec_b2 !== b2) errorCount++;
                symbolsCount += 2;
            }
            simBerEl.textContent = (errorCount / symbolsCount).toFixed(4);
            VISIBLE_BITS = 8; // show more bits for QPSK
        }

        charts.constellation.data.datasets[0].data = simBuffer.constellation;
        charts.constellation.update('none');
        drawEyeDiagram();

        // Update Audio Noise Base
        if (audioCtx && audioEnabled) {
            noiseGain.gain.value = 1 / (snrLinear + 1); // rough mapping for noise volume
        }

        return true;
    }

    function animate() {
        if (!isPaused) {
            const windowSize = VISIBLE_BITS * POINTS_PER_BIT;
            
            if (currentOffset + windowSize >= simBuffer.time.length) {
                currentOffset = 0;
            }

            const sliceStart = Math.floor(currentOffset);
            const sliceEnd = Math.floor(currentOffset + windowSize);

            const updateChartData = (chart, labels, data) => {
                chart.data.labels = labels;
                chart.data.datasets[0].data = data;
                chart.update('none');
            };

            const tSlice = simBuffer.time.slice(sliceStart, sliceEnd);
            updateChartData(charts.msg, tSlice, simBuffer.msg.slice(sliceStart, sliceEnd));
            updateChartData(charts.bpsk, tSlice, simBuffer.bpsk.slice(sliceStart, sliceEnd));
            updateChartData(charts.noisy, tSlice, simBuffer.noisy.slice(sliceStart, sliceEnd));
            updateChartData(charts.demod, tSlice, simBuffer.demod.slice(sliceStart, sliceEnd));

            // Sonification Feedback
            if (audioEnabled && osc) {
                const currentBit = simBuffer.msg[sliceStart];
                // Pitch shifting based on current bit
                if (modeSelect.value === 'BPSK') {
                    osc.frequency.setTargetAtTime(currentBit === 1 ? 600 : 400, audioCtx.currentTime, 0.05);
                } else {
                    // Just basic freq map
                    osc.frequency.setTargetAtTime(400 + (currentBit * 100), audioCtx.currentTime, 0.05);
                }
            }

            currentOffset += scrollSpeed;
        }
        animationId = requestAnimationFrame(animate);
    }

    function runSimulation(resetOffset = true) {
        if (animationId) {
            cancelAnimationFrame(animationId);
            animationId = null;
        }
        
        if (generateDataBuffer()) {
            if (resetOffset) {
                currentOffset = 0;
            } else {
                const maxOffset = simBuffer.time.length - (VISIBLE_BITS * POINTS_PER_BIT);
                if (currentOffset > maxOffset || isNaN(currentOffset)) {
                    currentOffset = 0;
                }
            }
            animate();
        }
    }

    // Event Listeners
    modeSelect.addEventListener('change', () => runSimulation(true));
    
    speedInput.addEventListener('input', (e) => {
        scrollSpeed = parseFloat(e.target.value);
        let lbl = 'Normal';
        if(scrollSpeed < 1) lbl = 'Slow Motion';
        if(scrollSpeed > 4) lbl = 'Fast';
        speedValue.textContent = lbl;
    });

    snrInput.addEventListener('input', (e) => {
        snrValue.textContent = e.target.value + ' dB';
        runSimulation(false); 
    });
    
    phaseInput.addEventListener('input', (e) => {
        phaseValue.textContent = e.target.value + '°';
        runSimulation(false); 
    });

    bitsInput.addEventListener('input', () => {
        runSimulation(false);
    });

    randomizeBtn.addEventListener('click', () => {
        let randomStr = '';
        for(let i = 0; i < 16; i++) {
            randomStr += Math.random() > 0.5 ? '1' : '0';
        }
        bitsInput.value = randomStr;
        runSimulation(true); 
    });

    pauseBtn.addEventListener('click', () => {
        isPaused = !isPaused;
        pauseBtn.textContent = isPaused ? 'Resume' : 'Pause';
        pauseBtn.classList.toggle('pause-active', isPaused);
    });

    simulateBtn.addEventListener('click', () => {
        isPaused = false;
        pauseBtn.textContent = 'Pause';
        pauseBtn.classList.remove('pause-active');
        runSimulation(true);
    });

    audioBtn.addEventListener('click', () => {
        audioEnabled = !audioEnabled;
        if (audioEnabled) {
            initAudio();
            masterGain.gain.setTargetAtTime(0.05, audioCtx.currentTime, 0.1);
            audioBtn.classList.add('audio-active');
            audioBtn.textContent = '🔊 Audio Enabled';
        } else {
            if (masterGain) masterGain.gain.setTargetAtTime(0, audioCtx.currentTime, 0.1);
            audioBtn.classList.remove('audio-active');
            audioBtn.textContent = '🔇 Enable Audio';
        }
    });

    // Handle Window Resize for Eye Diagram
    window.addEventListener('resize', () => {
        if (!isPaused) drawEyeDiagram();
    });

    // Initial Setup
    initCharts();
    runSimulation(true);
});
