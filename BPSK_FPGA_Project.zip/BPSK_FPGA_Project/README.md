# Design, Implementation and Simulation of a Baseband BPSK Communication System using FPGA

**Authors:** Nguyen Khoi Nguyen, Dao Duc Toan, Phan Tran Duy Khuong, Pham Huu Quoc Khang, Nguyen Duc Duy  
**Affiliation:** Department of Semiconductor & Digital Automotive Engineering, FPT University, Ho Chi Minh City, Vietnam

---

## Abstract
This paper presents the architectural design, Register Transfer Level (RTL) implementation, and detailed simulation of a complete Baseband Binary Phase Shift Keying (BPSK) digital communication system targeting Field-Programmable Gate Array (FPGA) platforms. To bridge the gap between theoretical communications and practical hardware synthesis, we developed a BPSK transceiver entirely in Verilog HDL. The system comprises a Pseudo-Random Bit Sequence (PRBS) generator, a Look-Up Table (LUT) based modulator, an Additive White Gaussian Noise (AWGN) channel simulator leveraging the Central Limit Theorem, a coherent demodulator featuring an Integrate-and-Dump matched filter, and a real-time Bit Error Rate (BER) evaluation module. Experimental simulations confirm that the hardware model aligns precisely with theoretical Q-function BER curves. Furthermore, an interactive web-based simulator featuring I/Q Constellation Diagrams and Phase Offset analysis was developed to vividly visualize signal degradation mechanisms under noise.

**Index Terms:** BPSK, FPGA, Verilog HDL, AWGN, Bit Error Rate, Digital Communications, Matched Filter.

---

## I. Introduction
Digital communication forms the critical infrastructure of the modern information era, spanning from high-speed 5G networks and Internet of Things (IoT) sensors to deep-space satellite telemetry. Modulating digital data onto analog carriers is a fundamental step in rendering baseband data suitable for physical channel transmission [1]. Among fundamental digital modulation schemes, Binary Phase Shift Keying (BPSK) is widely recognized for its superior noise immunity and power efficiency. By encoding binary data as 180-degree phase shifts of a carrier wave, BPSK maximizes the Euclidean distance between signal states, offering the lowest error probability for a given signal-to-noise ratio (SNR) compared to amplitude or frequency modulation [2].

While high-level software simulations (e.g., MATLAB, GNU Radio) are standard for analyzing telecommunications, they often abstract away the rigorous timing, synchronization, and resource constraints inherent in actual silicon hardware [3]. FPGAs, with their highly parallel architecture and deterministic latency, are the industry standard for real-time Digital Signal Processing (DSP) and modern Software-Defined Radios (SDR). This research aims to design a fully synthesizable RTL model of a BPSK transceiver, thereby providing a practical engineering implementation of theoretical telecommunication concepts.

## II. Theoretical Background

### A. BPSK Modulation and Constellation
In BPSK, the transmitted signal is mathematically represented in the continuous time domain as:

`s(t) = A · cos(2πf_c t + φ_i(t))`

where `A` represents the peak amplitude, `f_c` is the carrier frequency, and `φ_i(t) ∈ {0, π}` is the phase angle determined by the binary message. Specifically, a binary '1' is mapped to `φ = 0°`, and a binary '0' is mapped to `φ = 180°`. This effectively allows the signal to be expressed as a polar non-return-to-zero (NRZ) data stream multiplied by the carrier:

`s(t) = m(t) · A · cos(2πf_c t)`

where `m(t) ∈ {+1, -1}`. Utilizing a single orthogonal basis function `φ_1(t) = √(2/T_b) · cos(2πf_c t)`, BPSK can be represented on a one-dimensional signal space (the In-phase axis). The Euclidean distance between the two constellation points is `d = 2√E_b`, maximizing discriminability at the receiver.

### B. AWGN Channel and Bit Error Rate
The Additive White Gaussian Noise (AWGN) model is the standard benchmark for evaluating communication systems. For coherent BPSK over an AWGN channel, the noise `n(t)` is added to the transmitted signal. The noise possesses a uniform two-sided Power Spectral Density (PSD) of `N_0 / 2` and follows a Gaussian probability distribution function.

The theoretical probability of a bit error (`P_e`) occurs when the noise pushes a transmitted symbol across the decision boundary (the origin). This probability is mathematically derived using the Q-function:

`P_e = Q(√(2E_b / N_0))`

where `E_b / N_0` represents the bit energy to noise power spectral density ratio. This theoretical curve serves as the absolute baseline for validating our hardware implementation.

## III. Hardware Architecture and Implementation
The system was designed using a top-down hierarchical approach in Verilog HDL. The RTL architecture avoids floating-point arithmetic and complex trigonometric functions, strictly adhering to synthesizable digital design principles.

### A. Pseudo-Random Data Generation
To facilitate continuous testing without external data dependencies, the data source is implemented as an 8-bit Linear Feedback Shift Register (LFSR). Utilizing the primitive polynomial `G(x) = x^8 + x^6 + x^5 + x^4 + 1`, the module generates a maximal-length Pseudo-Random Bit Sequence (PRBS) of 255 bits, ensuring a statistically uniform distribution of 1s and 0s.

### B. BPSK Modulator via Look-Up Table
Calculating sine waves in hardware using Taylor series is resource-intensive. Instead, the modulator utilizes a Read-Only Memory (ROM) Look-Up Table (LUT) containing 32 quantized samples of a sine wave. A phase accumulator sequentially addresses the ROM to reconstruct the carrier wave. The BPSK modulation itself is achieved highly efficiently: if the incoming bit is 1, the LUT value is passed unmodified; if 0, the value undergoes a Two's Complement inversion (multiplied by -1), executing an instant 180-degree phase shift without trigonometric overhead.

### C. Digital AWGN Channel Simulator
Simulating true Gaussian noise on an FPGA is computationally demanding. To circumvent the need for complex Box-Muller transforms, we leveraged the Central Limit Theorem (CLT). The theorem dictates that the sum of independent, uniformly distributed random variables tends toward a Gaussian distribution. Our channel model sums the outputs of three independent 8-bit LFSRs running on disparate seeds. The resultant approximately Gaussian noise is scaled by an SNR-dependent coefficient and added to the modulated signal.

### D. Coherent Demodulator and Matched Filter
The receiver assumes perfect carrier synchronization. The noisy incoming signal is first multiplied by a local reference carrier generated by an identical Sine LUT. This multiplication produces a baseband DC component containing the data and a high-frequency component at twice the carrier frequency.

To isolate the data optimally in the presence of AWGN, a digital Integrate-and-Dump filter is implemented. A synchronous accumulator sums the multiplier's output over exactly one bit period (32 samples). This integration inherently low-pass filters the signal and maximizes the SNR at the sampling instant. At the end of the symbol period, a Decision Block evaluates the Most Significant Bit (MSB, or sign bit) of the accumulator. A positive value (MSB = 0) is decoded as a '1', and a negative value (MSB = 1) is decoded as a '0'.

## IV. Simulation Results and Discussion

### A. Experimental Setup
To validate the Verilog RTL and visualize signal integrity phenomena, an interactive web-based simulator (BPSK Pro Simulator) was developed. This tool mirrors the hardware's fixed-point arithmetic and sampling rate, offering real-time time-domain and I/Q spatial analysis.

### B. Time-Domain Analysis
Waveform analysis confirms the operational integrity of the pipeline. At high SNR scenarios, phase reversals at bit transitions are distinctly visible in the modulated signal. At an SNR of 0 dB, the sinusoidal carrier is completely obscured by noise. Despite this severe degradation, the Integrate-and-Dump filter's accumulator trace reliably drifts toward the correct positive or negative decision threshold, demonstrating the robustness of the matched filter approach.

### C. I/Q Constellation and Carrier Phase Offset
The simulator plots the integrated symbols on an I/Q Constellation Diagram. Under ideal synchronization, the symbols cluster tightly on the In-Phase (I) axis. However, local oscillator mismatches are common in practical receivers. We simulated Carrier Phase Offsets to observe this degradation. An offset of `45°` rotates the constellation, reducing the effective amplitude on the I-axis by a factor of `cos(45°) = 0.707`, thereby increasing vulnerability to noise. A `90°` offset rotates the constellation entirely onto the Quadrature (Q) axis, resulting in an I-axis integration of zero and complete data loss. This empirically validates the absolute necessity of Carrier Recovery loops (e.g., Costas Loop) in coherent receivers.

### D. Bit Error Rate (BER) Performance
The hardware's BER was quantified by comparing the delayed transmitted PRBS against the demodulated output. Table I delineates the simulated hardware BER versus the theoretical Q-function curve.

**TABLE I. BER Performance Comparison**

| SNR (dB) | Theoretical BER | Hardware BER |
| :---: | :---: | :---: |
| 10 | 3.87 × 10^-6 | 0.0000 |
| 6 | 2.38 × 10^-3 | ~ 0.0025 |
| 3 | 2.28 × 10^-2 | ~ 0.0240 |
| 0 | 7.86 × 10^-2 | ~ 0.0810 |

The empirical hardware error rates exhibit a negligible margin of error when compared to theoretical limits, verifying the mathematical precision of the RTL design and the AWGN simulator.

### E. Hardware Utilization
By substituting floating-point arithmetic with LUTs and shifting operations, the architecture is highly resource-efficient. Synthesis estimations on modern FPGAs (e.g., Xilinx Artix-7) project that the entire transceiver utilizes less than 1% of available Slice LUTs and Flip-Flops, positioning it as a lightweight Intellectual Property (IP) core suitable for integration into broader System-on-Chip (SoC) architectures.

## V. Conclusion
This project successfully architected and implemented a complete BPSK digital communication system in Verilog HDL. The resulting RTL design perfectly mirrors theoretical Q-function performance under AWGN environments while remaining strictly synthesizable for FPGA deployment. The avoidance of complex trigonometry in favor of LUTs and the application of the Central Limit Theorem for noise generation highlight effective hardware-software co-design strategies. The accompanying interactive visualization tool provided profound insights into signal degradation phenomena such as noise variance and phase offsets. Future work will focus on integrating Analog-to-Digital Converters (ADC/DAC) for physical RF channel transmission and expanding the architecture to incorporate Carrier Recovery mechanisms and Quadrature Phase Shift Keying (QPSK).

## VI. References
[1] J. G. Proakis and M. Salehi, *Digital Communications*, 5th ed. New York, NY, USA: McGraw-Hill, 2008.  
[2] B. P. Lathi and Z. Ding, *Modern Digital and Analog Communication Systems*, 4th ed. Oxford University Press, 2009.  
[3] S. Haykin, *Communication Systems*, 4th ed. John Wiley & Sons, 2001.  
[4] W. Wolf, *FPGA-Based System Design*. Upper Saddle River, NJ: Prentice Hall PTR, 2004.  
[5] C. E. Shannon, "A mathematical theory of communication," *The Bell System Technical Journal*, vol. 27, no. 3, pp. 379-423, 1948.  
[6] Xilinx Inc., *Artix-7 FPGAs Data Sheet: DC and AC Switching Characteristics*, DS181, 2021.
