`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: awgn_channel
// Description: Simplified Additive White Gaussian Noise (AWGN) channel model.
//              Uses multiple LFSRs to approximate Gaussian noise (Central Limit Theorem)
//////////////////////////////////////////////////////////////////////////////////

module awgn_channel(
    input wire clk,
    input wire reset,
    input wire signed [7:0] signal_in,
    input wire [3:0] noise_level, // Controls amplitude of noise
    output wire signed [7:0] signal_out
);

    // 3 LFSRs with different seeds to generate uniformly distributed random numbers
    reg [7:0] lfsr1, lfsr2, lfsr3;
    
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            lfsr1 <= 8'hA1;
            lfsr2 <= 8'hB2;
            lfsr3 <= 8'hC3;
        end else begin
            lfsr1 <= {lfsr1[6:0], lfsr1[7] ^ lfsr1[5] ^ lfsr1[4] ^ lfsr1[3]};
            lfsr2 <= {lfsr2[6:0], lfsr2[7] ^ lfsr2[6] ^ lfsr2[5] ^ lfsr2[1]};
            lfsr3 <= {lfsr3[6:0], lfsr3[7] ^ lfsr3[4] ^ lfsr3[3] ^ lfsr3[2]};
        end
    end

    // Combine LFSRs to approximate Gaussian distribution (CLT)
    // Shift them to be zero-mean signed values (-128 to 127)
    wire signed [8:0] noise1 = $signed({1'b0, lfsr1}) - 9'sd128;
    wire signed [8:0] noise2 = $signed({1'b0, lfsr2}) - 9'sd128;
    wire signed [8:0] noise3 = $signed({1'b0, lfsr3}) - 9'sd128;
    
    // Sum and scale by noise_level
    wire signed [10:0] combined_noise = (noise1 + noise2 + noise3);
    wire signed [7:0] scaled_noise = combined_noise[10:3] * noise_level;

    // Add noise to signal and handle saturation (clipping)
    wire signed [9:0] noisy_signal_ext = signal_in + scaled_noise;
    
    reg signed [7:0] clipped_signal;
    always @(*) begin
        if (noisy_signal_ext > 10'sd127)
            clipped_signal = 8'sd127;
        else if (noisy_signal_ext < -10'sd128)
            clipped_signal = -8'sd128;
        else
            clipped_signal = noisy_signal_ext[7:0];
    end

    assign signal_out = clipped_signal;

endmodule
