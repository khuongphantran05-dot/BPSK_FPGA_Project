`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: bpsk_modulator
// Description: BPSK Modulator. Generates a carrier and flips its phase 
//              (multiplies by -1) when input bit is 0.
//////////////////////////////////////////////////////////////////////////////////

module bpsk_modulator(
    input wire clk,
    input wire reset,
    input wire bit_in,
    output wire signed [7:0] modulated_out,
    output wire signed [7:0] carrier_ref // Reference carrier for demodulator
);

    // Phase accumulator
    reg [4:0] phase_acc;
    always @(posedge clk or posedge reset) begin
        if (reset)
            phase_acc <= 5'd0;
        else
            phase_acc <= phase_acc + 1'b1;
    end

    // Carrier generation
    wire signed [7:0] carrier;
    sine_lut lut_inst (
        .clk(clk),
        .address(phase_acc),
        .sine_val(carrier)
    );

    // Modulate: if bit_in is 1, output = carrier. if bit_in is 0, output = -carrier.
    assign modulated_out = bit_in ? carrier : -carrier;
    assign carrier_ref = carrier;

endmodule
