`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: bpsk_system_tb
// Description: Testbench for BPSK System
//////////////////////////////////////////////////////////////////////////////////

module bpsk_system_tb;

    // Inputs
    reg clk;
    reg reset;
    reg enable;
    reg [3:0] noise_level;

    // Outputs
    wire [31:0] total_bits;
    wire [31:0] error_bits;

    // Instantiate the Unit Under Test (UUT)
    bpsk_system_top uut (
        .clk(clk), 
        .reset(reset), 
        .enable(enable), 
        .noise_level(noise_level), 
        .total_bits(total_bits), 
        .error_bits(error_bits)
    );

    // Clock generation (100MHz = 10ns period)
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        reset = 1;
        enable = 0;
        noise_level = 0; // No noise initially

        // Wait 100 ns for global reset to finish
        #100;
        
        reset = 0;
        enable = 1;
        
        // Test with Noise Level = 0
        #10000;
        
        // Add medium noise
        noise_level = 4'd5;
        #20000;
        
        // Add high noise
        noise_level = 4'd12;
        #20000;

        $stop; // End simulation
    end
      
endmodule
