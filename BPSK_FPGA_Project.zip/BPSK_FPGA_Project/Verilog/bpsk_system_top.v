`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: bpsk_system_top
// Description: Top Level module connecting all BPSK simulation components
//////////////////////////////////////////////////////////////////////////////////

module bpsk_system_top(
    input wire clk,
    input wire reset,
    input wire enable,
    input wire [3:0] noise_level,
    output wire [31:0] total_bits_out,
    output wire [31:0] error_bits_out
);

    // 1 bit = 32 clock cycles (for the 32-sample Sine LUT)
    reg [4:0] bit_counter;
    wire bit_sync = (bit_counter == 5'd31);
    
    always @(posedge clk or posedge reset) begin
        if (reset)
            bit_counter <= 5'd0;
        else if (enable)
            bit_counter <= bit_counter + 1'b1;
    end

    // 1. Data Generator (PRBS)
    wire data_bit;
    prbs_generator prbs_inst (
        .clk(clk),
        .reset(reset),
        .enable(bit_sync), // Generate new bit every 32 cycles
        .prbs_out(data_bit)
    );

    // Delay data_bit to align with the receiver's output for BER calculation
    // Modulator + Demodulator + Decision adds 1 bit period of latency
    reg data_bit_delayed;
    always @(posedge clk) begin
        if (bit_sync) begin
            data_bit_delayed <= data_bit;
        end
    end

    // 2. Modulator
    wire signed [7:0] modulated_signal;
    wire signed [7:0] carrier_ref;
    
    bpsk_modulator mod_inst (
        .clk(clk),
        .reset(reset),
        .bit_in(data_bit),
        .modulated_out(modulated_signal),
        .carrier_ref(carrier_ref)
    );

    // 3. AWGN Channel
    wire signed [7:0] noisy_signal;
    
    awgn_channel channel_inst (
        .clk(clk),
        .reset(reset),
        .signal_in(modulated_signal),
        .noise_level(noise_level),
        .signal_out(noisy_signal)
    );

    // 4. Demodulator
    wire signed [15:0] integrator_val;
    wire dump_valid;
    
    bpsk_demodulator demod_inst (
        .clk(clk),
        .reset(reset),
        .bit_sync(bit_sync),
        .noisy_signal(noisy_signal),
        .carrier_ref(carrier_ref),
        .integrator_out(integrator_val),
        .dump_valid(dump_valid)
    );

    // 5. Decision Block
    wire decided_bit;
    wire bit_valid;
    
    decision_block dec_inst (
        .clk(clk),
        .reset(reset),
        .integrator_in(integrator_val),
        .dump_valid(dump_valid),
        .decided_bit(decided_bit),
        .bit_valid(bit_valid)
    );

    // 6. BER Calculator
    ber_calculator ber_inst (
        .clk(clk),
        .reset(reset),
        .original_bit(data_bit_delayed),
        .decided_bit(decided_bit),
        .bit_valid(bit_valid),
        .total_bits(total_bits_out),
        .error_bits(error_bits_out)
    );

endmodule
