`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: FPT University - Khoa Vi Mạch Bán Dẫn & Oto Số
// Engineer: BPSK Project Team
// 
// Create Date: 2026-07-01
// Module Name: prbs_generator
// Project Name: BPSK Digital Communication System
// Target Devices: FPGA
// Description: LFSR based Pseudo Random Bit Sequence (PRBS) generator
//////////////////////////////////////////////////////////////////////////////////

module prbs_generator(
    input wire clk,
    input wire reset,
    input wire enable,
    output reg prbs_out
);

    // 8-bit LFSR with polynomial x^8 + x^6 + x^5 + x^4 + 1
    reg [7:0] lfsr;
    wire feedback;

    assign feedback = lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3];

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            lfsr <= 8'b10101010; // Non-zero seed
            prbs_out <= 1'b0;
        end else if (enable) begin
            lfsr <= {lfsr[6:0], feedback};
            prbs_out <= lfsr[7];
        end
    end

endmodule
