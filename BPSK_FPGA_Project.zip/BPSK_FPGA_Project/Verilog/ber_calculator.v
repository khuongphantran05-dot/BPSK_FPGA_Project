`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: ber_calculator
// Description: Compares received bits with original delayed bits to count errors.
//////////////////////////////////////////////////////////////////////////////////

module ber_calculator(
    input wire clk,
    input wire reset,
    input wire original_bit,
    input wire decided_bit,
    input wire bit_valid,
    output reg [31:0] total_bits,
    output reg [31:0] error_bits
);

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            total_bits <= 32'd0;
            error_bits <= 32'd0;
        end else if (bit_valid) begin
            total_bits <= total_bits + 1'b1;
            if (original_bit != decided_bit) begin
                error_bits <= error_bits + 1'b1;
            end
        end
    end

endmodule
