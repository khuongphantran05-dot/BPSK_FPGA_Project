`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: bpsk_demodulator
// Description: Coherent BPSK Demodulator (Integrate and Dump)
//////////////////////////////////////////////////////////////////////////////////

module bpsk_demodulator(
    input wire clk,
    input wire reset,
    input wire bit_sync, // Pulse indicating end of a bit period
    input wire signed [7:0] noisy_signal,
    input wire signed [7:0] carrier_ref,
    output reg signed [15:0] integrator_out,
    output reg dump_valid
);

    // Multiplier
    wire signed [15:0] multiplied = noisy_signal * carrier_ref;
    
    // Integrator
    reg signed [15:0] acc;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            acc <= 16'd0;
            integrator_out <= 16'd0;
            dump_valid <= 1'b0;
        end else begin
            if (bit_sync) begin
                integrator_out <= acc + multiplied; // Dump
                dump_valid <= 1'b1;
                acc <= 16'd0; // Reset integrator
            end else begin
                acc <= acc + multiplied; // Integrate
                dump_valid <= 1'b0;
            end
        end
    end

endmodule
