`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: decision_block
// Description: Decision circuit for BPSK (threshold at 0)
//////////////////////////////////////////////////////////////////////////////////

module decision_block(
    input wire clk,
    input wire reset,
    input wire signed [15:0] integrator_in,
    input wire dump_valid,
    output reg decided_bit,
    output reg bit_valid
);

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            decided_bit <= 1'b0;
            bit_valid <= 1'b0;
        end else begin
            if (dump_valid) begin
                // BPSK Decision: if integrator > 0 then bit 1, else bit 0
                decided_bit <= (integrator_in > 0) ? 1'b1 : 1'b0;
                bit_valid <= 1'b1;
            end else begin
                bit_valid <= 1'b0;
            end
        end
    end

endmodule
