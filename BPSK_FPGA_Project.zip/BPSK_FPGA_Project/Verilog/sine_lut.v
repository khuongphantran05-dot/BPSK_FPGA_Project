`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: sine_lut
// Description: Sine Wave Look-Up Table (32 samples, 8-bit signed amplitude)
//////////////////////////////////////////////////////////////////////////////////

module sine_lut(
    input wire clk,
    input wire [4:0] address,
    output reg signed [7:0] sine_val
);

    always @(posedge clk) begin
        case(address)
            5'd0 : sine_val <= 8'sd0;
            5'd1 : sine_val <= 8'sd24;
            5'd2 : sine_val <= 8'sd48;
            5'd3 : sine_val <= 8'sd70;
            5'd4 : sine_val <= 8'sd90;
            5'd5 : sine_val <= 8'sd106;
            5'd6 : sine_val <= 8'sd117;
            5'd7 : sine_val <= 8'sd125;
            5'd8 : sine_val <= 8'sd127;
            5'd9 : sine_val <= 8'sd125;
            5'd10: sine_val <= 8'sd117;
            5'd11: sine_val <= 8'sd106;
            5'd12: sine_val <= 8'sd90;
            5'd13: sine_val <= 8'sd70;
            5'd14: sine_val <= 8'sd48;
            5'd15: sine_val <= 8'sd24;
            5'd16: sine_val <= -8'sd0;
            5'd17: sine_val <= -8'sd24;
            5'd18: sine_val <= -8'sd48;
            5'd19: sine_val <= -8'sd70;
            5'd20: sine_val <= -8'sd90;
            5'd21: sine_val <= -8'sd106;
            5'd22: sine_val <= -8'sd117;
            5'd23: sine_val <= -8'sd125;
            5'd24: sine_val <= -8'sd127;
            5'd25: sine_val <= -8'sd125;
            5'd26: sine_val <= -8'sd117;
            5'd27: sine_val <= -8'sd106;
            5'd28: sine_val <= -8'sd90;
            5'd29: sine_val <= -8'sd70;
            5'd30: sine_val <= -8'sd48;
            5'd31: sine_val <= -8'sd24;
            default: sine_val <= 8'sd0;
        endcase
    end

endmodule
